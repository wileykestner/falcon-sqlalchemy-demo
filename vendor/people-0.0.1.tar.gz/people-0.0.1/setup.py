from setuptools import setup

setup(name="people",
      version="0.0.1",
      test_suite="test_people",
      packages=["people", "test_people"])
