import pytest

from test_people import InMemoryPeopleRepository
from test_people import PeopleRepositoryContract


class TestInMemoryPeopleRepository(PeopleRepositoryContract):
    @pytest.fixture
    def a_people_repository(self):
        return InMemoryPeopleRepository()
