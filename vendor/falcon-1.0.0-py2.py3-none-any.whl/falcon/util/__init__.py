# Hoist misc. utils
from falcon.util.misc import *  # NOQA
from falcon.util.time import *
from falcon.util import structures

CaseInsensitiveDict = structures.CaseInsensitiveDict
